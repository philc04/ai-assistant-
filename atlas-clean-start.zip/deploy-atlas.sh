#!/usr/bin/env bash
set -euo pipefail

# Remove the old ZIP-only deployment artifacts from the repository.
if git ls-files --error-unmatch atlas-assistant-phone-sanitized.zip >/dev/null 2>&1; then
  git rm -f -- atlas-assistant-phone-sanitized.zip
else
  rm -f -- atlas-assistant-phone-sanitized.zip 2>/dev/null || true
fi

if git ls-files --error-unmatch atlas-clean-start.zip >/dev/null 2>&1; then
  git rm -f -- atlas-clean-start.zip
else
  rm -f -- atlas-clean-start.zip 2>/dev/null || true
fi

# Stage only the Atlas application files.
git add -- .gitignore README.md app next-env.d.ts package.json public tsconfig.json

if git diff --cached --quiet; then
  echo "Atlas files are already committed."
else
  git commit -m "Deploy Atlas clean start"
fi

git push origin HEAD:main

echo "Atlas source is now on main. Vercel should start a new deployment automatically."
