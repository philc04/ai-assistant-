"use client";

import { FormEvent, useEffect, useRef, useState } from "react";

type ChatMessage = { role: "user" | "assistant"; content: string };

const WELCOME: ChatMessage = {
  role: "assistant",
  content: "I’m Atlas. Tell me what you need done."
};

export default function Home() {
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [memory, setMemory] = useState("");
  const [busy, setBusy] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const savedMessages = localStorage.getItem("atlas.messages");
      const savedMemory = localStorage.getItem("atlas.memory");
      if (savedMessages) setMessages(JSON.parse(savedMessages));
      if (savedMemory) setMemory(savedMemory);
    } catch {}

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("atlas.messages", JSON.stringify(messages));
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    localStorage.setItem("atlas.memory", memory);
  }, [memory]);

  async function send(event: FormEvent) {
    event.preventDefault();
    const text = input.trim();
    if (!text || busy) return;

    const userMessage: ChatMessage = { role: "user", content: text };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setInput("");
    setBusy(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages, memory })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error || `Request failed (${response.status})`);
      setMessages((current) => [...current, { role: "assistant", content: data.text }]);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown error";
      setMessages((current) => [...current, { role: "assistant", content: `Error: ${message}` }]);
    } finally {
      setBusy(false);
    }
  }

  function newChat() {
    setMessages([WELCOME]);
    localStorage.removeItem("atlas.messages");
    setDrawerOpen(false);
  }

  const memoryPanel = (
    <div className="memoryPanel">
      <label htmlFor="memory">Core memory</label>
      <textarea
        id="memory"
        value={memory}
        onChange={(event) => setMemory(event.target.value)}
        placeholder="Preferences, goals, recurring context..."
      />
      <p>Saved on this device for now.</p>
    </div>
  );

  return (
    <main className="appShell">
      <aside className="sidebar">
        <div className="brand">
          <span>PERSONAL AI</span>
          <h1>ATLAS</h1>
          <p>Your assistant. Your context. Your tools.</p>
        </div>
        {memoryPanel}
        <button className="secondary" onClick={newChat}>New conversation</button>
      </aside>

      <section className="chat">
        <header>
          <div>
            <strong>Atlas</strong>
            <span className="online">● online</span>
          </div>
          <button className="menu" onClick={() => setDrawerOpen(true)} aria-label="Open settings">☰</button>
        </header>

        <div className="messages">
          {messages.map((message, index) => (
            <article className={`message ${message.role}`} key={`${message.role}-${index}`}>
              <span className="role">{message.role === "user" ? "YOU" : "ATLAS"}</span>
              <div className="bubble">{message.content}</div>
            </article>
          ))}
          {busy && (
            <article className="message assistant">
              <span className="role">ATLAS</span>
              <div className="bubble">Thinking…</div>
            </article>
          )}
          <div ref={endRef} />
        </div>

        <form className="composer" onSubmit={send}>
          <textarea
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder="Ask Atlas anything…"
            rows={1}
          />
          <button type="submit" disabled={!input.trim() || busy}>{busy ? "…" : "Send"}</button>
        </form>
      </section>

      {drawerOpen && (
        <div className="overlay">
          <button className="backdrop" aria-label="Close settings" onClick={() => setDrawerOpen(false)} />
          <aside className="drawer">
            <div className="drawerHeader">
              <strong>Atlas settings</strong>
              <button onClick={() => setDrawerOpen(false)} aria-label="Close settings">×</button>
            </div>
            {memoryPanel}
            <button className="secondary" onClick={newChat}>New conversation</button>
          </aside>
        </div>
      )}
    </main>
  );
}
