import OpenAI from "openai";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

export async function GET() {
  return NextResponse.json({ ok: true, service: "atlas-chat" });
}

export async function POST(request: Request) {
  const apiKey = process.env.OPENAI_API_KEY;

  if (!apiKey) {
    return NextResponse.json(
      { error: "OPENAI_API_KEY is missing in Vercel Environment Variables." },
      { status: 500 }
    );
  }

  try {
    const body = await request.json();
    const messages = Array.isArray(body?.messages) ? (body.messages as ChatMessage[]) : [];
    const memory = typeof body?.memory === "string" ? body.memory.slice(0, 12000) : "";

    const input = messages.slice(-30).map((message) => ({
      role: message.role,
      content: String(message.content ?? "").slice(0, 20000)
    }));

    if (!input.length) {
      return NextResponse.json({ error: "No chat message was supplied." }, { status: 400 });
    }

    const client = new OpenAI({ apiKey });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5",
      reasoning: { effort: "medium" },
      instructions: [
        "You are Atlas, a private personal AI assistant.",
        "Be practical, concise, capable, and action-oriented.",
        "You can use web search when current public information is needed.",
        "Never claim an external action happened unless a tool actually performed it.",
        memory ? `User-maintained core memory:\n${memory}` : "No user-maintained core memory is saved yet."
      ].join("\n\n"),
      input,
      tools: [{ type: "web_search" }]
    });

    return NextResponse.json({ text: response.output_text || "Atlas returned no text." });
  } catch (error) {
    console.error("Atlas chat error", error);
    const message = error instanceof Error ? error.message : "Unknown server error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
