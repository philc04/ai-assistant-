# Atlas Assistant

A mobile-first personal AI assistant built with Next.js, TypeScript, and the OpenAI Responses API.

## Required environment variables

- `OPENAI_API_KEY` (required)
- `OPENAI_MODEL` (optional, defaults to `gpt-5.1`)

Never commit `.env` files or API keys.

## Vercel

Import the repository into Vercel, add `OPENAI_API_KEY` under Project Settings > Environment Variables, then deploy.
