# Atlas Assistant

A personal AI assistant built with Next.js and OpenAI's Responses API.

## Current features

- Installable phone PWA (iPhone/iPad/Android)
- Full-screen standalone app experience from the home screen
- Mobile settings drawer with editable Core Memory
- Chat UI that works on desktop and mobile
- GPT-5.1 by default
- Built-in OpenAI web search tool
- Local conversation + memory persistence on the current device
- Server-side API key protection
- Service worker for cached app shell (AI requests still require internet)
- Extension points for Gmail, Calendar, files, voice, databases, and custom tools

## Run locally

1. Install Node.js 20+.
2. Create `.env.local` and add:

```env
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-5.1
```

3. Run:

```bash
npm install
npm run dev
```

Then open `http://localhost:3000`.

## Put it on your phone

The app must be hosted over HTTPS for normal phone installation. Vercel is the easiest option for this Next.js project.

Once deployed:

### iPhone / iPad
1. Open the deployed Atlas URL in Safari.
2. Tap Share.
3. Tap **Add to Home Screen**.
4. Open Atlas from the new home-screen icon.

### Android
1. Open the deployed Atlas URL in Chrome.
2. Open the browser menu.
3. Tap **Install app** or **Add to Home screen**.

## Important

The OpenAI API key stays on the server. Never put it in browser-side code or commit `.env.local` to GitHub.

The current memory and chat history are local to each browser/device. Atlas v0.2 should move these to a private database so your phone and computer share the same assistant memory.

## Recommended next build layers

1. Supabase/Postgres user account + durable cross-device memory
2. Structured memories with automatic extraction and deletion controls
3. Gmail and Google Calendar OAuth tools
4. File upload and searchable personal knowledge base
5. Voice input/output and realtime voice
6. Tasks, reminders, and recurring automations
7. Tool permission system: Ask / Allow once / Always allow
