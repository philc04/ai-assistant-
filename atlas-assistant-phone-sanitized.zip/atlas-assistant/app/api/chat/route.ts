import OpenAI from "openai";
import { NextResponse } from "next/server";

export const runtime = "nodejs";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

type Message = { role: "user" | "assistant"; content: string };

export async function POST(req: Request) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "OPENAI_API_KEY is not configured." }, { status: 500 });
    }

    const body = await req.json();
    const messages = (body.messages ?? []) as Message[];
    const memory = typeof body.memory === "string" ? body.memory.slice(0, 12000) : "";

    const recentMessages = messages.slice(-24).map(m => ({
      role: m.role,
      content: m.content.slice(0, 20000)
    }));

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.1",
      reasoning: { effort: "medium" },
      instructions: `You are Atlas, the user's private general-purpose AI assistant. Be practical, capable, concise, and action-oriented. Help with planning, research, writing, learning, technical work, and day-to-day decisions. Never claim to have completed external actions unless a tool actually performed them. Treat the following as user-maintained long-term context:\n\n${memory || "No saved memory yet."}`,
      input: recentMessages,
      tools: [{ type: "web_search" }]
    });

    return NextResponse.json({ text: response.output_text || "I completed the request but received no text output." });
  } catch (error) {
    console.error(error);
    const message = error instanceof Error ? error.message : "Unknown server error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
