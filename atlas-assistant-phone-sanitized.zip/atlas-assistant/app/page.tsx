"use client";

import { FormEvent, useEffect, useMemo, useRef, useState } from "react";

type Message = { role: "user" | "assistant"; content: string };

const STARTER: Message = {
  role: "assistant",
  content: "I’m Atlas. Give me an outcome, not a ceremony. What are we doing?"
};

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([STARTER]);
  const [input, setInput] = useState("");
  const [memory, setMemory] = useState("");
  const [busy, setBusy] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const savedMessages = localStorage.getItem("atlas.messages");
    const savedMemory = localStorage.getItem("atlas.memory");
    if (savedMessages) {
      try { setMessages(JSON.parse(savedMessages)); } catch {}
    }
    if (savedMemory) setMemory(savedMemory);

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("atlas.messages", JSON.stringify(messages));
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    localStorage.setItem("atlas.memory", memory);
  }, [memory]);

  const canSend = useMemo(() => input.trim().length > 0 && !busy, [input, busy]);

  async function send(e: FormEvent) {
    e.preventDefault();
    if (!canSend) return;

    const userMessage: Message = { role: "user", content: input.trim() };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setInput("");
    setBusy(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages, memory })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");
      setMessages(prev => [...prev, { role: "assistant", content: data.text }]);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Something failed";
      setMessages(prev => [...prev, { role: "assistant", content: `Error: ${message}` }]);
    } finally {
      setBusy(false);
    }
  }

  function resetChat() {
    setMessages([STARTER]);
    localStorage.removeItem("atlas.messages");
    setSettingsOpen(false);
  }

  const memoryEditor = (
    <section className="memoryCard">
      <div className="sectionTitle">Core memory</div>
      <textarea
        value={memory}
        onChange={e => setMemory(e.target.value)}
        placeholder="Things Atlas should keep in mind: preferences, goals, recurring context..."
      />
      <p className="tiny">Stored locally on this device in the MVP. Database-backed memory comes next.</p>
    </section>
  );

  return (
    <main className="shell">
      <aside className="sidebar">
        <div>
          <div className="eyebrow">PERSONAL AI</div>
          <h1>ATLAS</h1>
          <p className="muted">Your assistant. Your data. Your tools.</p>
        </div>

        {memoryEditor}
        <button className="secondary" onClick={resetChat}>New conversation</button>
      </aside>

      <section className="chatPanel">
        <header>
          <div>
            <strong>Atlas</strong>
            <span className="status">● online</span>
          </div>
          <div className="headerActions">
            <span className="model">GPT-5.1</span>
            <button className="mobileSettings" onClick={() => setSettingsOpen(true)} aria-label="Open Atlas settings">☰</button>
          </div>
        </header>

        <div className="messages">
          {messages.map((m, i) => (
            <article key={i} className={`message ${m.role}`}>
              <div className="role">{m.role === "user" ? "YOU" : "ATLAS"}</div>
              <div className="bubble">{m.content}</div>
            </article>
          ))}
          {busy && (
            <article className="message assistant">
              <div className="role">ATLAS</div>
              <div className="bubble typing">Thinking…</div>
            </article>
          )}
          <div ref={endRef} />
        </div>

        <form className="composer" onSubmit={send}>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                e.currentTarget.form?.requestSubmit();
              }
            }}
            placeholder="Ask Atlas to do something…"
            rows={1}
          />
          <button disabled={!canSend}>{busy ? "Working" : "Send"}</button>
        </form>
      </section>

      {settingsOpen && (
        <div className="mobileOverlay" role="dialog" aria-modal="true" aria-label="Atlas settings">
          <button className="backdrop" onClick={() => setSettingsOpen(false)} aria-label="Close settings" />
          <aside className="mobileDrawer">
            <div className="drawerTop">
              <div>
                <div className="eyebrow">ATLAS</div>
                <strong>Settings</strong>
              </div>
              <button className="closeButton" onClick={() => setSettingsOpen(false)} aria-label="Close settings">×</button>
            </div>
            {memoryEditor}
            <button className="secondary" onClick={resetChat}>New conversation</button>
          </aside>
        </div>
      )}
    </main>
  );
}
